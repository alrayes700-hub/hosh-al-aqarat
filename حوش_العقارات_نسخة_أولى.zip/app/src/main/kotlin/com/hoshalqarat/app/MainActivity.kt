package com.hoshalqarat.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Petrol = Color(0xFF075E54)
private val Gold = Color(0xFFFFC107)
private val LightBg = Color(0xFFF5F7F6)

data class Property(
    val title: String,
    val location: String,
    val type: String,
    val area: String,
    val price: String,
    val description: String
)

val demoProperties = listOf(
    Property("منزل للبيع في الثورة الحارة 77", "أم درمان • الثورة • الحارة 77", "منزل", "392 م²", "85,000,000 ج", "منزل مكون من دور واحد، موقع مميز وقريب من شارع النص."),
    Property("قطعة أرض في الثورة الحارة 70", "أم درمان • الثورة • الحارة 70", "أرض", "300 م²", "130,000,000 ج", "قطعة أرض شمال شارع كبري الحلفايا، مناسبة للسكن والاستثمار."),
    Property("نص بيت للبيع في الثورة", "أم درمان • الثورة • الحارة 76", "منزل", "189 م²", "85,000,000 ج", "نص بيت يحتوي على مطبخ وحمام، مناسب للسكن.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HoshApp() }
    }
}

@Composable
fun HoshApp() {
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Property?>(null) }
    var search by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Petrol,
            secondary = Gold,
            background = LightBg
        )
    ) {
        if (selected != null) {
            PropertyDetails(selected!!) { selected = null }
        } else {
            Scaffold(
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                        NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("المفضلة") })
                        NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("إضافة") })
                        NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
                    }
                }
            ) { pad ->
                when (tab) {
                    0 -> Home(Modifier.padding(pad), search, { search = it }) { selected = it }
                    1 -> EmptyPage(Modifier.padding(pad), "المفضلة", "ستظهر هنا العقارات التي تحفظها.")
                    2 -> AddProperty(Modifier.padding(pad))
                    3 -> EmptyPage(Modifier.padding(pad), "حسابي", "تسجيل الدخول وإدارة عقاراتك ستكون متاحة في الإصدار التالي.")
                }
            }
        }
    }
}

@Composable
fun Home(modifier: Modifier, search: String, onSearch: (String) -> Unit, onOpen: (Property) -> Unit) {
    val filtered = demoProperties.filter {
        search.isBlank() || "${it.title} ${it.location} ${it.type}".contains(search, true)
    }
    LazyColumn(
        modifier.fillMaxSize().background(LightBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("حوش العقارات", color = Petrol, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("كل العقارات في حوش واحد", color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = onSearch,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("ابحث عن عقار أو منطقة") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    shape = RoundedCornerShape(18.dp),
                    singleLine = true
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(true, {}, label = { Text("الكل") })
                    FilterChip(false, {}, label = { Text("للبيع") })
                    FilterChip(false, {}, label = { Text("للإيجار") })
                }
                Spacer(Modifier.height(8.dp))
                Text("أحدث العقارات", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(filtered) { p ->
            PropertyCard(p) { onOpen(p) }
        }
    }
}

@Composable
fun PropertyCard(p: Property, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(82.dp).background(Petrol.copy(alpha = .12f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Home, null, tint = Petrol, modifier = Modifier.size(38.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(p.location, color = Color.Gray, fontSize = 13.sp)
                    Text("${p.type} • ${p.area}", color = Petrol, fontSize = 13.sp)
                    Text(p.price, color = Petrol, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Icon(Icons.Default.FavoriteBorder, null, tint = Petrol)
            }
        }
    }
}

@Composable
fun PropertyDetails(p: Property, back: () -> Unit) {
    Column(Modifier.fillMaxSize().background(LightBg)) {
        Row(
            Modifier.fillMaxWidth().background(Petrol).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("تفاصيل العقار", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.padding(18.dp)) {
            Box(
                Modifier.fillMaxWidth().height(220.dp).background(Petrol.copy(alpha = .12f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Home, null, tint = Petrol, modifier = Modifier.size(80.dp)) }
            Spacer(Modifier.height(16.dp))
            Text(p.title, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text(p.location, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text(p.price, color = Petrol, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("المساحة: ${p.area}   •   النوع: ${p.type}", fontSize = 16.sp)
            Spacer(Modifier.height(16.dp))
            Text("وصف العقار", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text(p.description, color = Color.DarkGray, lineHeight = 25.sp)
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:0908959145"))
                    },
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Default.Phone, null); Spacer(Modifier.width(5.dp)); Text("اتصال") }
                OutlinedButton(
                    onClick = { },
                    modifier = Modifier.weight(1f)
                ) { Text("واتساب") }
            }
        }
    }
}

@Composable
fun AddProperty(modifier: Modifier) {
    Column(modifier.fillMaxSize().background(LightBg).padding(18.dp)) {
        Text("إضافة عقار", color = Petrol, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("أدخل بيانات العقار وسيظهر للمستخدمين بعد المراجعة.", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("عنوان العقار") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("الموقع / الحارة") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("السعر") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), label = { Text("المساحة") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth().height(110.dp), label = { Text("وصف العقار") })
        Spacer(Modifier.height(16.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("إرسال العقار للمراجعة")
        }
    }
}

@Composable
fun EmptyPage(modifier: Modifier, title: String, message: String) {
    Column(
        modifier.fillMaxSize().background(LightBg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.HomeWork, null, tint = Petrol, modifier = Modifier.size(70.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(message, textAlign = TextAlign.Center, color = Color.Gray)
    }
}
