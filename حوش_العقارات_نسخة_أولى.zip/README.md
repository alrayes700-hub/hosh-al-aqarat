# حوش العقارات

نسخة أولية (MVP) لتطبيق Android عربي لبيع وشراء وتأجير العقارات.

## التقنية
- Kotlin
- Jetpack Compose
- Material 3
- Android SDK 35
- Min SDK 24

## التشغيل
1. افتح المشروع في Android Studio.
2. انتظر مزامنة Gradle.
3. شغّل التطبيق على محاكي أو هاتف Android.
4. لبناء APK: Build > Build APK(s).

## المرحلة التالية
- Firebase Authentication
- Firestore لبيانات العقارات
- Firebase Storage للصور
- رفع الصور من الهاتف
- تحديد الموقع على الخريطة
- واتساب واتصال فعليان
- لوحة إدارة
- مراجعة الإعلانات
- الإعلانات المميزة
